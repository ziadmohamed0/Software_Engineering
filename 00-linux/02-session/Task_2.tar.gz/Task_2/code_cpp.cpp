#include <iostream>

int main(void) {
	unsigned int x, y, z; 
	x = 10;
	y = 20;
	z = x + y;
	std::cout<< "number 1 = " << x << std::endl;
	std::cout<< "number 2 = " << y << std::endl;
	std::cout << "result of number 1 + number 2 = " << z << std::endl; 
	return 0;
}
